import React from 'react';
import './HomePage.css';

const HomePage = () => {
  return (
    <div className="homepage">
      <div className="welcome-box">
        <h1>Welcome to FitSync</h1>
        <p>If you're new here, please register to start your fitness journey!</p>
      </div>
    </div>
  );
};

export default HomePage;
