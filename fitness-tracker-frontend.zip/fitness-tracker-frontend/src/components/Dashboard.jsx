import React from 'react';
import './Dashboard.css';

const Dashboard = () => {
  return (
    <div className="dashboard-container">
      <div className="dashboard-card">
        <h1>Welcome to Your Dashboard</h1>
        <p>Here you’ll be able to track your workouts, goals, and progress.</p>

        <div className="dashboard-grid">
          <div className="dashboard-widget">
            <h3>Today's Activity</h3>
            <p>Steps: 0</p>
            <p>Calories: 0</p>
          </div>
          <div className="dashboard-widget">
            <h3>Weekly Progress</h3>
            <p>Coming soon...</p>
          </div>
          <div className="dashboard-widget">
            <h3>Workout Planner</h3>
            <p>Coming soon...</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
