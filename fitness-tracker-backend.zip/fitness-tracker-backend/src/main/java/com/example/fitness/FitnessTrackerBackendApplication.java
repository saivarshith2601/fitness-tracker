package com.example.fitness;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FitnessTrackerBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FitnessTrackerBackendApplication.class, args);
	}

}
